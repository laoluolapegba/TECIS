﻿
namespace TECIS.Web.Helpers.CrossCutting.Logging
{
    public class LogHelper
    {
        public void DbLog()
        {
            //var culture = System.Globalization.CultureInfo.CurrentCulture.ToString();
            //System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.CurrentCulture();
            //ci.NumberFormat.CurrencySymbol = "₦";
        }
    }
}