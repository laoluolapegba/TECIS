﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TECIS.Web.Controllers
{
    public class MiscellaneousController : Controller
    {

        public ActionResult GoogleMaps()
        {
            return View();
        }

        public ActionResult CodeEditor()
        {
            return View();
        }

        public ActionResult ModalWindow()
        {
            return View();
        }

        public ActionResult NestableList()
        {
            return View();
        }

        public ActionResult Validation()
        {
            return View();
        }

        public ActionResult Notification()
        {
            return View();
        }

        public ActionResult Timeline_second_version()
        {
            return View();
        }

        public ActionResult Forum_view()
        {
            return View();
        }

        public ActionResult Forum_post_view()
        {
            return View();
        }

        public ActionResult Tree_view()
        {
            return View();
        }

        public ActionResult Chat_view()
        {
            return View();
        }

        public ActionResult AgileBoard()
        {
            return View();
        }

        public ActionResult Diff()
        {
            return View();
        }

        public ActionResult SweetAlert()
        {
            return View();
        }

        public ActionResult IdleTimer()
        {
            return View();
        }

        public ActionResult Spinners()
        {
            return View();
        }

        public ActionResult LiveFavicon()
        {
            return View();
        }

        public ActionResult Masonry()
        {
            return View();
        }

	}
}