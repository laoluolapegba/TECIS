﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TECIS.Web.Controllers
{
    public class AppViewsController : Controller
    {

        public ActionResult Contacts()
        {
            return View();
        }
     
        public ActionResult Profile()
        {
            return View();
        }

        public ActionResult Contacts2()
        {
            return View();
        }

        public ActionResult Profile2()
        {
            return View();
        }
        
        public ActionResult Projects()
        {
            return View();
        }
       
        public ActionResult ProjectDetail()
        {
            return View();
        }
        
        public ActionResult FileManager()
        {
            return View();
        }
        
        public ActionResult Calendar()
        {
            return View();
        }
        
        public ActionResult FAQ()
        {
            return View();
        }
        
        public ActionResult Timeline()
        {
            return View();
        }
        
        public ActionResult PinBoard()
        {
            return View();
        }

        public ActionResult TeamsBoard()
        {
            return View();
        }

        public ActionResult SocialFeed()
        {
            return View();
        }

        public ActionResult Clients()
        {
            return View();
        }

        public ActionResult OutlookView()
        {
            return View();
        }

        public ActionResult IssueTracker()
        {
            return View();
        }

        public ActionResult Blog()
        {
            return View();
        }

        public ActionResult Article()
        {
            return View();
        }

        public ActionResult VoteList()
        {
            return View();
        }

	}
}