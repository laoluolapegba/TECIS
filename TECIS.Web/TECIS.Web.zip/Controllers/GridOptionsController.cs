﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TECIS.Web.Controllers
{
    public class GridOptionsController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }
	}
}